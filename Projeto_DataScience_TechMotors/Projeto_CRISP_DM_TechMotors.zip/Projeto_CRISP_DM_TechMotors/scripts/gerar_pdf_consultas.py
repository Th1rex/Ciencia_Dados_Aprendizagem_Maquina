"""Gera TechMotors_Analysis.pdf no mesmo padrão visual do projeto de referência:
capa, uma consulta por página (título, SQL colorido e resultado em tabela) e página final.
As consultas vêm do techmotors.sql e são executadas no DuckDB sobre os CSVs de techmotors_data/."""
import html, re, sys
import duckdb
import weasyprint

repo = sys.argv[1] if len(sys.argv) > 1 else '.'
sql = open(f'{repo}/techmotors.sql', encoding='utf-8').read()
sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.S)
con = duckdb.connect()
arquivos = {
    'TipoServico': 'tipo_servico', 'Oficina': 'oficina',
    'CanalAgendamento': 'canal_agendamento', 'Cliente': 'cliente', 'Agendamento': 'agendamento'
}
KW = {'SELECT', 'FROM', 'WHERE', 'JOIN', 'ON', 'GROUP', 'BY', 'ORDER', 'HAVING', 'AS', 'AND', 'OR', 'CASE', 'WHEN',
      'THEN', 'ELSE', 'END', 'WITH', 'CREATE', 'VIEW', 'LIMIT', 'DESC', 'ASC', 'IS', 'NULL', 'NOT', 'DISTINCT',
      'OVER', 'WITHIN', 'DATE', 'CAST', 'IN'}
FN = {'SUM', 'COUNT', 'AVG', 'ROUND', 'MIN', 'MAX', 'PERCENTILE_CONT', 'DATE_TRUNC', 'COALESCE'}
TOKEN = re.compile(r"('[^']*')|(\"[^\"]*\")|(\b\d+(?:\.\d+)?\b)|(\b[A-Za-z_]+\b)|(\s+)|(.)")

def colorir(codigo):
    out = []
    for s, ident, num, word, ws, other in TOKEN.findall(codigo):
        if s: out.append(f'<span class="str">{html.escape(s)}</span>')
        elif ident: out.append(html.escape(ident))
        elif num: out.append(f'<span class="num">{num}</span>')
        elif word:
            u = word.upper()
            cls = 'kw' if u in KW else ('fn' if u in FN else None)
            out.append(f'<span class="{cls}">{html.escape(word)}</span>' if cls else html.escape(word))
        else: out.append(html.escape(ws or other))
    return ''.join(out)

def fmt(v):
    if isinstance(v, float): return f'{v:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
    if isinstance(v, int): return f'{v:,}'.replace(',', '.')
    return html.escape(str(v)[:10] if hasattr(v, 'year') else str(v))

DECOR = '<div class="faixa"></div><div class="moldura"></div><div class="barras"><i style="height:38%"></i><i style="height:58%"></i><i style="height:46%"></i><i style="height:74%"></i><i style="height:92%"></i></div>'
paginas = [f'<section class="pagina capa">{DECOR}<div class="capa-texto"><h1>TechMotors<br>Análise<br>SQL</h1><p class="capa-sub">Validações, base limpa e KPIs do CRISP-DM</p><p class="capa-info">Ciência de Dados e Aprendizagem de Máquina (A1) · UDF<br>Profa. Kadidja Valéria</p><p class="capa-info">Eduardo Santos Morais (P1)<br>Thiago Regis Vieira Rocha (P2)</p><p class="capa-aviso">Dados simulados com a estrutura do TCC TechMotors:<br>250 clientes, 8 oficinas e 1.000 agendamentos (jan.–dez. 2026).</p></div></section>']

for stmt in [s.strip() for s in sql.split(';') if s.strip()]:
    linhas = stmt.splitlines()
    if 'CREATE TABLE' in stmt:
        con.execute(stmt)
        t = re.search(r'CREATE TABLE "(\w+)"', stmt).group(1)
        con.execute(f'INSERT INTO "{t}" SELECT * FROM read_csv(\'{repo}/techmotors_data/{arquivos[t]}.csv\', header=true)')
        continue
    comentarios = [l.strip()[2:].strip() for l in linhas if l.strip().startswith('--') and not l.strip().startswith('-- =')]
    comentarios = [c for c in comentarios if c and not c.isupper()]
    codigo = '\n'.join(l for l in linhas if not l.strip().startswith('--')).strip()
    if not codigo: continue
    if 'CREATE VIEW' in stmt:
        con.execute(stmt)
        titulo, nota = 'View agendamento_limpo -- base limpa usada pelos KPIs (Fase 3)', ' '.join(c for c in comentarios if c.startswith('-'))
        resultado = '<p class="obs">A view não retorna uma tabela: ela é a base que os KPIs consultam a seguir.</p>'
    else:
        ini = next((i for i, c in enumerate(comentarios) if re.match(r'^(V\d|KPI \d|[AB]\.)', c)), 0)
        titulo, nota = comentarios[ini], ' '.join(comentarios[ini + 1:])
        df_q = con.execute(codigo).df()
        cab = '<th></th>' + ''.join(f'<th>{html.escape(str(c))}</th>' for c in df_q.columns)
        rows = ''.join(f'<tr><td class="n">{i}</td>' + ''.join(f'<td>{fmt(v)}</td>' for v in r) + '</tr>'
                       for i, r in enumerate(df_q.itertuples(index=False), 1))
        largo = ' class="largo"' if len(df_q.columns) > 5 else ''
        resultado = f'<table{largo}><tr>{cab}</tr>{rows}</table>'
        m = re.match(r'^(V\d|KPI \d|[AB])\.?\s*(.*)$', titulo)
        titulo = f'{m.group(1)} -- {m.group(2)}' if m else titulo
    nota_html = f'<p class="nota">-- {html.escape(nota)}</p>' if nota else ''
    pequeno = ' pequeno' if codigo.count('\n') > 16 else ''
    paginas.append(f'<section class="pagina">{DECOR}<div class="conteudo"><p class="titulo">-- {html.escape(titulo)}</p>{nota_html}<pre class="sql{pequeno}">{colorir(codigo)}</pre><div class="res">{resultado}</div></div></section>')

paginas.append(f'<section class="pagina capa">{DECOR}<div class="capa-texto fim"><h1>Obrigado!</h1><p class="capa-sub">TechMotors · Análise SQL</p></div></section>')
print(f"Script pronto para {len(paginas)} páginas.")
