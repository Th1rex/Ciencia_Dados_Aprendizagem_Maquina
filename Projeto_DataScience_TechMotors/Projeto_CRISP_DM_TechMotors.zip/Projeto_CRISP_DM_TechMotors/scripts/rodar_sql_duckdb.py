"""Executa o techmotors.sql no DuckDB, carregando os CSVs de techmotors_data/.
Uso: python scripts/rodar_sql_duckdb.py"""
import duckdb, re, sys

repo = sys.argv[1] if len(sys.argv) > 1 else "."
sql = open(f'{repo}/techmotors.sql', encoding='utf-8').read()
sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.S)
con = duckdb.connect()
loads = {
    'TipoServico': 'tipo_servico',
    'Oficina': 'oficina',
    'CanalAgendamento': 'canal_agendamento',
    'Cliente': 'cliente',
    'Agendamento': 'agendamento'
}
stmts = [s.strip() for s in sql.split(';') if s.strip() and not all(l.strip().startswith('--') or not l.strip() for l in s.splitlines())]
for s in stmts:
    head = [l for l in s.splitlines() if l.strip().startswith('--')]
    title = head[-1] if head else ''
    if 'CREATE TABLE' in s:
        con.execute(s)
        t = re.search(r'CREATE TABLE "(\w+)"', s).group(1)
        con.execute(f'INSERT INTO "{t}" SELECT * FROM read_csv(\'{repo}/techmotors_data/{loads[t]}.csv\', header=true)')
        print('loaded', t, con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone())
        continue
    if 'CREATE VIEW' in s:
        con.execute(s)
        print('view agendamento_limpo ok')
        continue
    print('\n', title)
    print(con.execute(s).df().to_string(index=False))
